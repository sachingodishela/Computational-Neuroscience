Physiologically known neuron types which can be represented by Izhikevich model:

1. Neocortical Neurons in mammalian brain (represented by RS, IB, CH models)
2. Inhibitory Cortical cells (represented by FS, LTS models)
3. Thalamo Cortical Neuron (represented by TC model)